/**
 * 
 */
/**
 * 
 */
module financial_position {
	requires java.desktop;
	requires java.sql;
}